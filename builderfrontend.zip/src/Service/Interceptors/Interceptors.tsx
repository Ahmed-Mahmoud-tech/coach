import React from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import axiosInstance, { axiosRefresh } from '../../Core/AxiosInstance/axiosInstance';
import { useAppDispatch } from '../../Core/Store/hooks';
import { signOut } from '../State/authSlice/authSlice';

const Interceptors = () => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  /**
   * @todo intercept any request and add the token to every request
   * @return the request with the token
   */
  axiosInstance.interceptors.request.use(
    function (config: any) {
      //check if iam not in login page
      if (config.url !== '/login') {
        const token = localStorage.getItem('userToken');
        //add the token from local storage to the header request
        config.headers.Authorization = token
          ? `Bearer ${JSON.parse(token).access_token}`
          : '';
      }
      //return the request with the token
      return config;
    },
    (error: any) => {
      //if err don't do any thing and i will handel it in my global handel error
      return Promise.reject(error);
    }
  );

  /**
   * @todo intercept any request and add the refresh token when the token is expired
   * @return the request with the refresh token
   */
  axiosRefresh.interceptors.request.use(function (config: any) {
    if (config.url !== '/login') {
      const token = localStorage.getItem('refreshToken');

      config.headers.Authorization = token
        ? `Bearer ${JSON.parse(token).access_token}`
        : '';
    }
    return config;
  });

  /**
   * @todo intercept any request and handel the global errors and show the right toaster
   * @return the error promise
   */
  axiosInstance.interceptors.response.use(
    (res: any) => {
      return res;
    },
    async (err: any) => {
      const originalConfig = err.config;
      if (err.response) {
        //when the Access Token is expired
        if (err.response.status === 401 && !originalConfig._retry) {
          // to check if the refresh token don't expired
          if (err.response.request.responseURL.includes('refresh')) {
            // if the refresh token expired clear the local storage and navigate to login
            localStorage.clear();
            navigate('/login');
            dispatch(signOut());
            return Promise.reject(err);
          }
          //to retry the current request with my new token when getting new one
          originalConfig._retry = true;
          try {
            //get the token and refresh token
            const res: any = await axiosRefresh.post('', {});
            const accessToken: any = res.data.data;
            // set it in the local storage
            localStorage.setItem('userToken', JSON.stringify(accessToken.token));
            localStorage.setItem(
              'refreshToken',
              JSON.stringify(accessToken.refresh_token)
            );
            // add the new token and replace it with the expired one
            axiosInstance.defaults.headers.common[
              'Authorization'
            ] = `Bearer ${accessToken.token.access_token}`;
            // call again
            return axiosInstance(originalConfig);
          } catch (_error: any) {
            // if error clear the navigate
            localStorage.clear();
            navigate('login');
            dispatch(signOut());
            return Promise.reject(_error);
          }
        }
        // with validations errors show toasters
        if (err.response.status === 422) {
          console.log('err', err.response);
          for (const key in err.response.data.errors) {
            const element = err.response.data.errors[key];
            for (const errMessage of element) {
              console.log(errMessage);
              toast.error(errMessage, {
                position: toast.POSITION.TOP_CENTER,
                toastId: 'uniqueId',
              });
            }
          }
        }
        // else just show error message with
        // validations errors
        if (err.response.status === 403) {
          toast.error(err.response.data.message, {
            position: toast.POSITION.TOP_CENTER,
            toastId: 'uniqueId',
          });
        }
        if (err.response.status === 429) {
          toast.error(err.response.data.message, {
            position: toast.POSITION.TOP_CENTER,
            toastId: 'uniqueId',
          });
        }
        // servers error
        if (err.response.status === 404 || err.response.status === 500) {
          toast.error('something went wrong \n please contact the IT', {
            position: toast.POSITION.TOP_CENTER,
            toastId: 'uniqueId',
          });
        }
        //internet and fire wall errors
        if (err.response.status === 0) {
          toast.error('no Internet connection \n please contact the IT', {
            position: toast.POSITION.TOP_CENTER,
            toastId: 'uniqueId',
          });
        } else {
          toast.error('something went wrong \n please contact the IT', {
            position: toast.POSITION.TOP_CENTER,
            toastId: 'uniqueId',
          });
        }
      }

      return Promise.reject(err);
    }
  );
  return <></>;
};

export default Interceptors;
