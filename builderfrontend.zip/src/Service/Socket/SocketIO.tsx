import React from 'react';
import io from 'socket.io-client';

const SocketIO = () => {
  const host = `${process.env.REACT_APP_API_URL}/socket`;

  const connect = () => {
    io().connect();
  };
  const disConnect = () => {
    io().disconnect();
  };
  const emit = (e: any, data: any) => {
    io().emit(e, data);
  };
  const socketOn = () => {
    io().on('start', () => {
      return 'ok';
    });
  };
  return <div></div>;
};

export default SocketIO;
