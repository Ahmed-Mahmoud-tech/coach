export interface IAuth {
  token: string;
  name: string;
  role: string;
  isAuth: boolean;
}
