import { createSlice } from '@reduxjs/toolkit';
import { RootState } from '../../../Core/Store/store';
import { IAuth } from './auth.interface';

//initial state for auth info
const initialState: IAuth = {
  token: '',
  name: '',
  role: '',
  isAuth: true,
};

/**
 * @todo
 * create my reducer && set actions to it
 *
 */
export const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    // when sign in get my data to my reducer
    signIn: (state, action) => {
      state.isAuth = action.payload;
    },
    // when sign out return my state to initial state
    signOut: (state) => {
      state = initialState;
    },
  },
});

// export my actions to dispatch hook
export const { signIn, signOut } = authSlice.actions;

// get my auth object from my selector hook
export const selectAuth = (state: RootState) => state.auth;

// export reducer to my state
export default authSlice.reducer;
