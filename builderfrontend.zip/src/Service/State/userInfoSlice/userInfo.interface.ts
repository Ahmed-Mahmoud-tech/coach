export interface IPermissions {
  name: string;
  value: number;
}

export interface IUserInfo {
  name: string;
  role: string;
  specification: string;
  permissions: IPermissions[];
}
