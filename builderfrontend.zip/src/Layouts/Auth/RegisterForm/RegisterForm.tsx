import React from 'react';

const RegisterForm = () => {
  return <div>RegisterForm</div>;
};

export default RegisterForm;
