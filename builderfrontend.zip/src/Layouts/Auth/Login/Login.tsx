import { Button } from 'primereact/button';
import React from 'react';
import { useNavigate } from 'react-router';
import { useAppDispatch } from '../../../Core/Store/hooks';
import { signIn } from '../../../Service/State/authSlice/authSlice';

const Login = () => {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  return (
    <div>
      <Button
        label="Submit"
        onClick={() => {
          dispatch(signIn(true));
          navigate('/');
        }}
      ></Button>
    </div>
  );
};

export default Login;
