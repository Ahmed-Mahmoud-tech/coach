import React, { lazy } from 'react';
import { Navigate, useRoutes } from 'react-router-dom';
import Auth from '../../Containers/Auth/Auth';
import ForgotPassword from '../../Layouts/Auth/ForgotPassword/ForgotPassword';
import Login from '../../Layouts/Auth/Login/Login';
import RegisterForm from '../../Layouts/Auth/RegisterForm/RegisterForm';
import ResetPassword from '../../Layouts/Auth/ResetPassword/ResetPassword';
import { selectAuth } from '../../Service/State/authSlice/authSlice';
import { selectUserInfo } from '../../Service/State/userInfoSlice/userInfoSlice';
import { useAppSelector } from '../Store/hooks';

const Routes = () => {
  //get the auth state to guard my home route
  const auth = useAppSelector(selectAuth);
  //get my role to guard and nested route
  const role = useAppSelector(selectUserInfo);

  // lazy loading my all components
  const Home = lazy(() => import('../../Containers/Home/Home'));
  const User = lazy(() => import('../../Containers/User/User'));
  const Survey = lazy(() => import('../../Containers/Survey/Survey'));
  const Perview = lazy(() => import('../../Containers/Perview/Perview'));
  const Results = lazy(() => import('../../Containers/Results/Results'));
  const NotFound = lazy(() => import('../../Layouts/NotFound/NotFound'));
  /**
   * @todo render my routes and my child routes
   */
  const routes = useRoutes([
    {
      path: 'login',
      element: <Auth />,
      children: [
        { path: '', element: <Login /> },
        { path: 'reset-password', element: <ResetPassword /> },
        { path: 'forgot-password', element: <ForgotPassword /> },
        { path: 'register-form', element: <RegisterForm /> },
      ],
    },
    {
      path: '/',
      element: auth.isAuth ? <Home /> : <Navigate to="login" />,
      children: [
        {
          path: 'user',
          element: role.role !== 'user' ? <User /> : <Navigate to="/login" />,
        },
        { path: 'survey', element: <Survey /> },
        { path: 'perview', element: <Perview /> },
        { path: 'results', element: <Results /> },
      ],
    },
    { path: '*', element: <NotFound /> },
  ]);
  return routes;
};

export default Routes;
