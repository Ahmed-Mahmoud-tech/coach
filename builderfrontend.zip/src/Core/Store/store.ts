import { configureStore, ThunkAction, Action } from '@reduxjs/toolkit';
import spinnerReducer from '../../Service/State/spinnerSlice/spinnerSlice';
import stepReducer from '../../Service/State/stepSlice/stepSlice';
import authReducer from '../../Service/State/authSlice/authSlice';
import userInfoReducer from '../../Service/State/userInfoSlice/userInfoSlice';
import toastReducer from '../../Service/State/toasterSlice/toasterSlice';

export const store = configureStore({
  reducer: {
    spinner: spinnerReducer,
    step: stepReducer,
    auth: authReducer,
    userInfo: userInfoReducer,
    toast: toastReducer,
  },
});

export type AppDispatch = typeof store.dispatch;
export type RootState = ReturnType<typeof store.getState>;
export type AppThunk<ReturnType = void> = ThunkAction<
  ReturnType,
  RootState,
  unknown,
  Action<string>
>;
