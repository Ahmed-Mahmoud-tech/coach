import React from 'react';

const Perview = () => {
  return <div>Perview</div>;
};

export default Perview;
