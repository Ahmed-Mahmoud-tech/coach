import React from 'react';

const Results = () => {
  return <div>Results</div>;
};

export default Results;
