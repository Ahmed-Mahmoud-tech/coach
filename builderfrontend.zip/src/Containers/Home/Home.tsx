import React from 'react';
import { Outlet } from 'react-router';
import { Link } from 'react-router-dom';
import { Warper } from './Home.style';

const Home = () => {
  return (
    <Warper>
      <nav style={{ width: '100%', height: '25px', backgroundColor: 'red' }}>
        <Link to="/user">user </Link>
        <Link to="/survey">survey </Link>
        <Link to="/perview">perview </Link>
        <Link to="/results">results </Link>
      </nav>
      <Outlet />
    </Warper>
  );
};

export default Home;
