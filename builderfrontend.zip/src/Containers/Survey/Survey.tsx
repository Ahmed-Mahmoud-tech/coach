import React, { useState, useEffect } from 'react';
import { Sidebar } from 'primereact/sidebar';
import { Warper } from './Survey.style';
import PollQuestion from '../../Components/FormControllers/PoolQuestion/PoolQuestion';
import CardQuestionSetting from '../../Components/FormControllers/CardQuestion/CardQuestionSetting/CardQuestionSetting';
import PatientProfile from '../../Components/FormControllers/PatientProfile/PatientProfile';
import RankImage from '../../Components/FormControllers/RankImages/RankImages';
import RankMessage from '../../Components/FormControllers/RankMessage/RankMessage';

import CardQuestionPreview from '../../Components/FormControllers/CardQuestion/CardQuestionPreview/CardQuestionPreview';

const Survey = () => {
  const [formData, setFormData] = useState<any>([]);
  const [fireUpdate,setFireUpdate] = useState<number>(0)
  const [currentQuestionId, setCurrentQuestionId] = useState<string>("");
  const [questionAction, setQuestionAction] = useState<string>("add");
  const [questionListMenu, setQuestionListMenu] = useState<boolean>(true);
  const [settingMenu, setSettingMenu] = useState<boolean>(false);
  const [currentSetting, setCurrentSetting] = useState<string>("pool")

  let questionSetting : any = {
    pool    : <PollQuestion formData={formData} setFormData={setFormData} setFireUpdate={setFireUpdate} questionId={currentQuestionId} questionAction={questionAction} />,
    card    : <CardQuestionSetting formData={formData} setFormData={setFormData} setFireUpdate={setFireUpdate} questionId={currentQuestionId} questionAction={questionAction}/>,
    image   : <RankImage formData={formData} setFormData={setFormData} setFireUpdate={setFireUpdate} questionId={currentQuestionId} questionAction={questionAction} />,
    message : <RankMessage formData={formData} setFormData={setFormData} setFireUpdate={setFireUpdate} questionId={currentQuestionId} questionAction={questionAction} />,
    profile : <PatientProfile formData={formData} setFormData={setFormData} setFireUpdate={setFireUpdate} questionId={currentQuestionId} questionAction={questionAction} />
  };

  let questionPreview : any = {
    card    : (questionData:()=>any, index:number)=><CardQuestionPreview formData={questionData} key={index}/>,
  };

  let questionsTypes:{type:string , name:string}[] = [
    {type:"pool", name:"Pool question"},
    {type:"card", name:"Card question"},
    {type:"image", name:"Rank Image"},
    {type:"message", name:"Rank Message"},
    {type:"profile", name:"Patient Profile"},
  ];


  const switchSideBar : () => void = () => {
    setSettingMenu(!settingMenu);
    setQuestionListMenu(settingMenu);
  }

  const changesetting = (type: string) => {
    setCurrentSetting(type);
    setCurrentQuestionId(Date.now().toString());
    switchSideBar();
  }


  return (
      <Warper>
          <div className="card">
              <Sidebar visible={questionListMenu} position="right" onHide={() => setQuestionListMenu(false)}>
                {
                  questionsTypes.map((item, index)=>{
                    return(
                      <h3 key={index} onClick={()=>changesetting(item.type)}>{item.name}</h3>
                    )
                  })
                }
              </Sidebar>

              <Sidebar visible={settingMenu} position="right" onHide={() => setSettingMenu(false)}>
                {questionSetting[`${currentSetting.toString()}`]}
              </Sidebar>

              <div className="add" onClick={() => !questionListMenu && settingMenu && switchSideBar() || !questionListMenu && !settingMenu && setQuestionListMenu(true) }>add</div>
                <div className="show">
                  {
                    formData.map((element:any, index:number)=>{
                      return questionPreview[element.type](element, index);
                    })
                  }
                </div>
            </div>
        </Warper>
  )
};

export default Survey;
