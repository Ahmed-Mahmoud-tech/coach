import styled from 'styled-components';

export const Warper = styled.div`
    background:#eee;
    min-height:100vh;
`;
