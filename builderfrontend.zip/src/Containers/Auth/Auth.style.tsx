import styled from 'styled-components';

export const Warper = styled.div`
  width: 100vw;
  height: 100vh;
  background-color: #eee;
  position: relative;
`;
export const Content = styled.div`
  padding: 1rem;
  position: absolute;
  border: 1px solid #333333;
  color: #fff;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background-color: #000;
`;
