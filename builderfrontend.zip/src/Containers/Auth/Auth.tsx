import React from 'react';
import { Link, Outlet } from 'react-router-dom';
import FormBuilder from '../../Components/FormBuilder/FormBuilder';
import { Content, Warper } from './Auth.style';
interface IFormData {
  controlType: string;
  formName: string;
  rules?: any;
  label?: string;
  url?: string;
  options?: FormOptions[];
  optionsLabel?: string;
  class?: string;
  value?: {};
}
interface FormOptions {
  name: string;
  id: any;
}

const Auth = () => {
  const items: IFormData[] = [
    {
      controlType: 'pool',
      formName: 'username',
    },
    {
      controlType: 'card',
      formName: 'name',
    },
    {
      controlType: 'textarea',
      formName: 'user',
    },
    {
      controlType: 'image',
      formName: 'image',
    },
    {
      controlType: 'message',
      formName: 'message',
    },
    {
      controlType: 'profile',
      formName: 'profile',
    },
  ];
  return (
    <Warper>
      <div>
        <Link to="/login/reset-password">reset_password </Link>
        <Link to="/login/forgot-password">forgot-password </Link>
        <Link to="/login/register-form">register-form </Link>
        <Link to="/login">login</Link>
      </div>
      <FormBuilder items={items} />
      <Content>
        <Outlet />
      </Content>
    </Warper>
  );
};

export default Auth;
