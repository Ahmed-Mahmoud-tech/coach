import React, { Suspense } from 'react';
import { BrowserRouter as Router } from 'react-router-dom';

import './App.css';
import Routes from './Core/Routes/Routes';

function App() {
  return (
    <Suspense fallback="Loding">
      <Router>
        <Routes />
      </Router>
    </Suspense>
  );
}

export default App;
