import React from 'react';

const PopUp = () => {
  return <div></div>;
};

export default PopUp;
