import React from 'react';

const Dialog = () => {
  return <div>Dialog</div>;
};

export default Dialog;
