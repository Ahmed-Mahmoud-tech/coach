import React from 'react';
import { DragDropContext, Draggable, Droppable } from 'react-beautiful-dnd';
import PoolQuestion from '../FormControllers/PoolQuestion/PoolQuestion';
import { CardQuestion } from '../FormControllers/CardQuestion/CardQuestionSetting/CardQuestionSetting';
import PatientProfile from '../FormControllers/PatientProfile/PatientProfile';
import RankMessage from '../FormControllers/RankMessage/RankMessage';
import RankImages from '../FormControllers/RankImages/RankImages';

interface IFormData {
  controlType: string;
  formName: string;
  rules?: any;
  label?: string;
  url?: string;
  options?: FormOptions[];
  optionsLabel?: string;
  class?: string;
  value?: {};
}
interface FormOptions {
  name: string;
  id: any;
}

const FormBuilder = (props: { items: IFormData[] }) => {
  const onDragEnd = (result: any) => {
    console.log('ok', result);
    const itemFromArr = props.items[result.source.index];
    props.items.splice(result.source.index, 1);
    props.items.splice(result.destination.index, 0, itemFromArr);
  };
  return (
    <div>
      <DragDropContext onDragEnd={onDragEnd}>
        <div>Hello world</div>
        <Droppable droppableId="form" type="PERSON">
          {(provided, snapshot) => (
            <div
              ref={provided.innerRef}
              style={{ backgroundColor: snapshot.isDraggingOver ? 'blue' : 'grey' }}
              {...provided.droppableProps}
            >
              <h2>I am a droppable!</h2>
              {props.items.map((item: IFormData, index: number) => {
                return (
                  <Draggable
                    key={item.formName}
                    draggableId={item.formName}
                    index={index}
                  >
                    {(provided, snapshot) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        {...provided.dragHandleProps}
                      >
                        {(function () {
                          switch (item.controlType) {
                            case 'pool':
                              return <PoolQuestion />;

                            case 'card':
                              return <CardQuestion />;

                            case 'profile':
                              return <PatientProfile />;

                            case 'message':
                              return <RankMessage />;

                            case 'image':
                              return <RankImages />;

                            default:
                              break;
                          }
                        })()}
                        {/* <h4>My draggable</h4> */}
                      </div>
                    )}
                  </Draggable>
                );
              })}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>
    </div>
  );
};

export default FormBuilder;
