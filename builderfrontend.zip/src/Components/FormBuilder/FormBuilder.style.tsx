import styled from 'styled-components';

export const Warper = styled.div``;
