import React from 'react';

const RankImages = (props:any) => {
  return <div>Rank Images {props.questionId}</div>;
};

export default RankImages;
