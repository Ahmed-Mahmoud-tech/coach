import React, {useEffect, useState } from 'react';
import { InputSwitch } from 'primereact/inputswitch';
import { Chips } from 'primereact/chips';

export const CardQuestion = (props:any) => {

  interface IquestionData {
    id:string,
    type:string,
    step:number,
    index:number,
    required:boolean,
    questionString:any
  }

  const [questionData, setQuestionData] = useState<IquestionData>({
    id:props.questionId,
    type:"card",
    step:1,
    index: props.formData?.length,
    required:false,
    questionString:[]
  });

  useEffect(() => {
    if(props.questionAction == "add"){
      props.setFormData([...props.formData, questionData]);
    }else if(props.questionAction == "edit"){
      let getQuestion = props.formData.filter(function (question:any) {
        return question.id == props.questionId;
      })
      setQuestionData(getQuestion)
    }
  },[])

  const updataQuestion = () => {
    let questions = props.formData;
    props.formData?.forEach(function(question:any, index:number) {
      if (question && (question.id === props.questionId)) {
          questions[index]=questionData;
          props.setFormData(questions);
          props.setFireUpdate((x:number)=>x+1)
          return;
        }
    });
  }

  useEffect(() => {
    updataQuestion();
  },[questionData])


  return (
            <div>
                <div className="card">
                    <h2>Card setting</h2>
                    <h5>required</h5>
                    <InputSwitch checked={questionData.required} onChange={(e) => setQuestionData({...questionData, required:e.value})} />
                    <h5>required</h5>
                    <Chips value={questionData.questionString} onChange={(e) => setQuestionData({...questionData, questionString:e.value})} />
                </div>
            </div>
        );
};

export default CardQuestion;