import React, {useEffect, useState } from 'react';
import { InputSwitch } from 'primereact/inputswitch';
import { Chips } from 'primereact/chips';

export const CardQuestion = (props:any) => {

  return (
            <div>
                {
                  Object.keys(props.formData).map(function(key, index) {
                    return <h1 key={index}>{key}:{props.formData[key].toString()}</h1>
                  })
                }
                <h1>.......................................</h1>

            </div>
        );
};

export default CardQuestion;