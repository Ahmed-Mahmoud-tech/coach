import React, {useEffect, useState } from 'react';
import { InputSwitch } from 'primereact/inputswitch';
import { Chips } from 'primereact/chips';


const PatientProfile = (props:any) => {

  interface IquestionData {
    id:string,
    index:number,
    required:boolean,
    questionString:string
  }
  const [required, setRequired] = useState<boolean>(false);
  const [questionString, setQuestionString] = useState<any>("");
  const [questionData, setQuestionData] = useState<IquestionData>({
    id:props.questionId,
    index: 0,
    required:false,
    questionString:questionString
  });

  useEffect(() => {
    if(props.questionAction == "add"){
      props.setFormData(...props.formData, questionData);
      var questionPlaceHolder = questionData;
      questionPlaceHolder.index = props.formData.length
      setQuestionData(questionPlaceHolder)
    }
  },[])

  const updataQuestion = () => {
    let questions = props.formData;
    props.formData.forEach(function(question:any, index:number) {
      if (question.id === props.questionId) {
          questions[index]=questionData;
          props.setFormData(questions)
        }
    });
  }

  return <div className="PatientProfile">
            <h2>PatientProfile setting</h2>
            <h5>required</h5>
            <InputSwitch checked={required} onChange={(e) => setRequired(e.value)} />
            <h5>required</h5>
            <Chips value={questionString} onChange={(e) => setQuestionString(e.value)} />
          </div>;
};


export default PatientProfile;
