import React from 'react';

const RankMessage = (props:any) => {
  return <div>Rank Message {props.questionId}</div>;
};

export default RankMessage;
