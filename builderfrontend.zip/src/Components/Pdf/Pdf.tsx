import React from 'react';

const Pdf = () => {
  return <div></div>;
};

export default Pdf;
