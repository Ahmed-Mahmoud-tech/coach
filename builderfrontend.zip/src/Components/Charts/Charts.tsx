import React from 'react';
import { Chart } from 'primereact/chart';

const Charts = () => {
  const options = {
    plugins: {
      title: {
        display: true,
        text: 'My Title',
        font: {
          size: 16,
        },
      },
      legend: {
        position: 'bottom',
        color: '#495057',
      },
    },
  };
  const data = {
    labels: ['A', 'B', 'C'],
    datasets: [
      {
        data: [300, 50, 100],
        backgroundColor: ['#42A5F5', '#66BB6A', '#FFA726'],
        hoverBackgroundColor: ['#64B5F6', '#81C784', '#FFB74D'],
      },
    ],
  };
  return (
    <Chart style={{ width: '500px' }} type="pie" data={data} options={options} />
  );
};

export default Charts;
