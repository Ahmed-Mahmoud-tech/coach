import React from 'react';
import { Button } from 'primereact/button';
import xlsx from 'xlsx';

const Excel = (props: { ExcelData: any }) => {
  /**
   * @todo download excel sheet
   * @return void
   */
  const downloadXlsx = (): void => {
    // make work sheet and load the data in it
    const workSheet = xlsx.utils.json_to_sheet(props.ExcelData);
    // the workbook is main file to get all the sheets if you have many
    const workBook = xlsx.utils.book_new();
    //append the sheets to the book
    xlsx.utils.book_append_sheet(workBook, workSheet, 'sheet1');
    // give it buffer and name
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const buffer = xlsx.writeFile(workBook, 'survey.xlsx');
    //download the book with its sheets in xlsx extension
    xlsx.write(workBook, { type: 'binary', bookType: 'xlsx' });
  };
  return (
    <Button label="Primary" className="p-button-raised" onClick={downloadXlsx} />
  );
};

export default Excel;
