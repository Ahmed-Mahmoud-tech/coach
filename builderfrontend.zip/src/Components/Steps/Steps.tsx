import React from 'react';

const Steps = () => {
  return <div></div>;
};

export default Steps;
